package com.tutorial.boson.ter;

import net.minecraft.tileentity.TileEntity;

public class ObsidianTERTileEntity extends TileEntity {
    public ObsidianTERTileEntity() {
        super(TileEntityTypeRegistry.obsidianTERTileEntity.get());
    }
}
