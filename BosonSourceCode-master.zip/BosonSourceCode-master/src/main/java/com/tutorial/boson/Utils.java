package com.tutorial.boson;

public class Utils {
    public static final String MOD_ID = "boson";
}
