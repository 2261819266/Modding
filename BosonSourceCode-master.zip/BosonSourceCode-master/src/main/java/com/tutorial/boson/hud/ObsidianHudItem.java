package com.tutorial.boson.hud;

import com.tutorial.boson.group.ModGroup;
import net.minecraft.item.Item;

public class ObsidianHudItem extends Item {
    public ObsidianHudItem() {
        super(new Properties().group(ModGroup.ITEM_GROUP));
    }
}
