package com.tutorial.boson.first_cap;

import net.minecraft.util.math.BlockPos;

public interface ISimpleCapability {
    String getString(BlockPos pos);
}
