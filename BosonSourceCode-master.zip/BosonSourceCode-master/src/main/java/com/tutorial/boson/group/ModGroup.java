package com.tutorial.boson.group;

import net.minecraft.item.ItemGroup;

public class ModGroup {
    public static final ItemGroup ITEM_GROUP = new ObsidianGroup();
}
